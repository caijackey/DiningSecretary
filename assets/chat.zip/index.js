
var SOCKET_URL = "http://192.168.3.71:99";
//var SOCKET_URL = "http://192.168.3.232:21275/chat";
var EMIT_POST = "post";
var LOADING_PANEL_ID = "loadingPanel";

var socket = null;
var chatPanel = null;
var hisMorePanel = null;

var pm = {
    chatGroup:'',                   //聊天室用户组 app:app客户端
    chatVer:'',                     //聊天室版本
    appVer:'',                      //app版本
    appType:'iphoneXmsApp',         //客户端类别
    deviceId:'',                    //设备id
    deviceOs:'',                    //设备操作系统
    deviceType:'',                  //设备类别
    deviceScreenWidth:0,            //设备屏幕宽度
    deviceScreenHeight:0,           //设备屏幕高度
    userToken:'',                   //用户token
    channelNum:'',                  //渠道号
    cityId:'',                      //城市id
    haveGpsTag:false,               //是否有gps
    lon:0,                          //纬度
    lat:0,                          //经度
    wifi:false,                     //是否是wifi访问
    currentPage:'',                 //当前页面
    needHisMsg:true,                //是否需要返回历史消息
    validateKey:'',                 //合法性验证key  和主app的验证字符串一样
    questionId:'',                  //问题id
    userPicUrl:'',                  //用户头像url
    
    roomKey:'',                     //房间号码
    chatterId:'',                   //聊天人id
    onChattingTag:false,            //是否在聊天状态
    prevId:'',                      //上一笔历史数据id
    onMinimizeTag:false,            //是否最小化了
    roomClosedTag:false             //房间是否已经关闭
};



/*------------------------------------------------------------------------------
 |  初始化
 |
 -----------------------------------------------------------------------------*/
//初始化
function initChat (
    chatVer,
    appVer,
    deviceId,
    deviceOs,
    deviceType,
    deviceScreenWidth,
    deviceScreenHeight,
    userToken,
    channelNum,
    cityId,
    haveGpsTag,
    lon,
    lat,
    wifi,
    currentPage,
    validateKey,
    questionId,
    userPicUrl
) {
	//先设置参数-----------------------------
	//聊天室版本
	pm.chatVer = chatVer;
	//app版本
	pm.appVer = appVer;
	//设备id
	pm.deviceId = deviceId;
	//设备操作系统
	pm.deviceOs = deviceOs;
	//设备类别
	pm.deviceType = deviceType;
	//设备屏幕宽度
	pm.deviceScreenWidth = deviceScreenWidth;
	//设备屏幕高度
	pm.deviceScreenHeight = deviceScreenHeight;
	//用户token
	pm.userToken = userToken;
	//渠道号
	pm.channelNum = channelNum;
	//城市id
	pm.cityId = cityId;
	//是否有gps
	pm.haveGpsTag = haveGpsTag;
	//纬度
	pm.lon = lon;
	//经度
	pm.lat = lat;
	//是否是wifi访问
	pm.wifi = wifi;
	//当前页面
	pm.currentPage = currentPage;
	//合法性验证key
	pm.validateKey = validateKey;
    //问题id
    pm.questionId = questionId;
    //用户头像url
    pm.userPicUrl = userPicUrl;

    
    //初始化面板控件-----------------------------
    //聊天面板
    chatPanel = $("#chatPanel");
    //更多历史面板
    hisMorePanel = $("#hisMorePanel");

    
	//连接聊天室--------------------------------
    //先显示加载面板
    showLoadMsg("接入中,请稍候...");
    //延迟连接到服务器
    setTimeout(connectToServer,300);
}
function connectToServer(){
    //连接socket
    socket = io.connect(SOCKET_URL, {
        'reconnection delay': 1000,
        'max reconnection attempts': 30
    });
    
    //connect
    socket.on("connect",function (obj) {
        //如果房间已经关闭 不处理
        if (pm.roomClosedTag) {
            return;
        }
        if (pm.roomKey=='') {
            sendMsgEnterRoom();
        } else {
            sendMsgBind();
        }
    });
    //disconnect
    socket.on("disconnect", function (obj) {
        //是否在聊天
        pm.onChattingTag = false;
    });
    //监控消息
    socket.on("msg",function (obj) {
        if (chkIsOffline()) {
            return;
        }
        var pack = new ChatPack(obj);
        var mp = new ChatMsgPack(pack.obj);
        processMsgListForWatch(mp.list);
    });
    
    //监控是否进入房间成功
    watchIsEnterRoomSucc();
}

var watchIsEnterRoomSuccNum = 0;
function watchIsEnterRoomSucc(){
    watchIsEnterRoomSuccNum++;
    if (watchIsEnterRoomSuccNum>=20) {
        showLoadMsg("接入失败");
        return;
    }

    //是否在聊天
    if (pm.onChattingTag==false) {
        setTimeout(watchIsEnterRoomSucc,1000);
    }
}



/*------------------------------------------------------------------------------
 |  发送消息
 |
 -----------------------------------------------------------------------------*/
//进入房间
function sendMsgEnterRoom() {
    socket.emit(EMIT_POST,{
        func:'enterRoom',
        chatGroup:pm.chatGroup,                        //聊天室用户组
        chatVer:pm.chatVer,                            //聊天室版本
        appVer:pm.appVer,                              //app版本
        appType:pm.appType,                            //客户端类别
        deviceId:pm.deviceId,                          //设备id
        deviceOs:pm.deviceOs,                          //设备操作系统
        deviceType:pm.deviceType,                      //设备类别
        deviceScreenWidth:pm.deviceScreenWidth ,       //设备屏幕宽度
        deviceScreenHeight:pm.deviceScreenHeight,      //设备屏幕高度
        userToken:pm.userToken,                        //用户token
        channelNum:pm.channelNum,                      //渠道号
        cityId:pm.cityId,                              //城市id
        haveGpsTag:pm.haveGpsTag,                      //是否有gps
        lon:pm.lon,                                    //纬度
        lat:pm.lat,                                    //经度
        wifi:pm.wifi,                                  //是否是wifi访问
        currentPage:pm.currentPage,                    //当前页面
        needHisMsg:pm.needHisMsg,                      //是否需要返回历史消息
        validateKey:pm.validateKey,                    //合法性验证key
        questionId:pm.questionId                       //问题id
    },function (obj) {
        //隐藏加载面板
        hideLoadMsg();
        //解析pack
        var pack = new ChatPack(obj);
        if (pack.code==200) {
            //是否在聊天状态
            pm.onChattingTag = true;
            //保存房间钥匙和聊天人id
            var o = new ChatEnterRoomData(pack.obj);
            pm.roomKey = o.roomKey;
            pm.chatterId = o.chatterId;
            //处理消息
            processHisMsg(o.hisMsg,true);
            //告诉客户端成功进入房间
            invokeUrl("chat://enterRoomSuccess");
        } else if (pack.code==201) {
            //关闭房间
            closeRoomNotInvokeRoomClose();
            //升级
            var curl = encodeURIComponent(pack.chatZipUrl);
            var cver = encodeURIComponent(pack.chatVer);
            invokeUrl("chat://enterRoomNeedUpgrade/"+curl+"/"+cver);
            //错误提示
            showErrorHint("升级中...");
        } else {
            //关闭房间
            closeRoom();
            //错误提示
            showErrorHint(pack.msg);
        }
    });
}

//重新绑定
function sendMsgBind(){
    socket.emit(EMIT_POST,{
        func:'bind',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId            //聊天人id
    },function (obj) {
        //解析pack
        var pack = new ChatPack(obj);
        if (pack.code==200) {
            //是否在聊天状态
            pm.onChattingTag = true;
        } else if (pack.code==201) {
            //重新进入房间
            sendMsgEnterRoom();
        } else {
            //关闭房间
            closeRoom();
            //错误提示
            showErrorHint(pack.msg);
        }
    });
}

//离开房间
function sendMsgLeaveRoom(){
    if (chkIsOffline()) {
        return;
    }
    
    socket.emit(EMIT_POST,{
        func:'leaveRoom',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId            //聊天人id
    },function (obj) {
        //关闭房间
        closeRoom();
    });
}

//关闭房间
function sendMsgCloseApp() {
    if (chkIsOffline()) {
        return;
    }
    
    socket.emit(EMIT_POST,{
        func:'closeApp',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId            //聊天人id
    },function (obj) {
        //关闭房间
        closeRoom();
    });
}

//发送文本
function sendMsgSendTxt(txt) {
    if (chkIsOffline()) {
        return;
    }

    //等待id
    var waitId = randomString(10);
    
    //显示html数据
    var md = new ChatMsgData();
	md.chatterIconUrl = pm.userPicUrl;
	md.dataStyleTag = 1;
    var d = new ChatMsgHtmlData();
    d.html = getCleanText(txt);
	md.data = d;
    doMsgHtml(md,true,waitId);
    //滚动到最底部
    scrollToBottom();
    
    //提交
    socket.emit(EMIT_POST,{
        func:'txt',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId,           //聊天人id
        txt:txt                           //文本信息
    },function (obj) {
        var pack = new ChatPack(obj);
        if (pack.code==200) {
            //隐藏等待
            var panel = $("#"+waitId);
            panel.hide();
        } else {
            alert("文本\"+txt+\"发送失败:"+pack.msg);
        }
    });
}

//发送gps
function sendMsgSendGps(haveGpsTag,lon,lat) {
    if (chkIsOffline()) {
        return;
    }

    socket.emit(EMIT_POST,{
        func:'sendGps',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId,           //聊天人id
        haveGpsTag:haveGpsTag,            //是否有gps
        lon:lon,                          //纬度
        lat:lat                           //经度
    });
}

//最小化房间
function sendMsgMinimizeRoom() {
    if (chkIsOffline()) {
        return;
    }
    
    //设置最小化标志位
    pm.onMinimizeTag = true;
    //提交
    socket.emit(EMIT_POST,{
        func:'minimizeRoom',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId            //聊天人id
    });
}

//最大化房间
function sendMsgMaximizeRoom(bp) {
    if (chkIsOffline()) {
        return;
    }
    
    //设置最小化标志位
    pm.onMinimizeTag = false;
    //提交
    socket.emit(EMIT_POST,{
        func:'maximizeRoom',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId,           //聊天人id
        browsePages:bp                    //浏览页面列表
    });
}

//获得上一笔历史记录
function sendMsgPrevHisMsgPack() {
    if (chkIsOffline()) {
        return;
    }

    //先隐藏更多历史面板
    hisMorePanel.hide();
    //提交
    socket.emit(EMIT_POST,{
        func:'prevHisMsgPack',
        roomKey:pm.roomKey,               //房间钥匙
        chatterId:pm.chatterId,           //聊天人id
        prevId:pm.prevId                  //上一笔数据id
    },function (obj) {
        var pack = new ChatPack(obj);
        if (pack.code==200) {
            var hm = new ChatHisMsgPack(pack.obj);
            //处理消息
            processHisMsg(hm,false);
        }
    });
}



/*------------------------------------------------------------------------------
 |  处理消息
 |
 ------------------------------------------------------------------------------*/
//处理历史消息
function processHisMsg(hm,forEnterRoomTag) {
    //是否有上一笔数据
    if (hm.havePrevTag) {
        hisMorePanel.show();
    } else {
        hisMorePanel.hide();
    }
	//保存上一笔历史数据id
	pm.prevId = hm.prevId;
    //处理消息
    processMsgListForHis(hm.list,forEnterRoomTag);
}

//处理消息列表
function processMsgListForWatch(list) {
    processMsgList(list,true,true);
}
function processMsgListForHis(list,appendTag) {
    processMsgList(list,appendTag,false);
}
function processMsgList(list,appendTag,needChkRoomKeyTag) {
    var visibleMsgNum = 0;//显式的消息数量
    var keyHtml = "html";
    if (appendTag) {
        for (var i=0;i<list.length;i++) {
            var md = list[i];
            //容错 比较房间号
            if (needChkRoomKeyTag && md.roomKey!=pm.roomKey) {
                continue;
            }
            
            //数据类型
            var dt = md.dataType;
            if (keyHtml==dt) {
                //显示html数据
                doMsgHtml(md,true,'');
                visibleMsgNum++;
            }
            //功能类型
            var ft = md.funcType;
            if ("needGps"==ft) {
                //需要获得gps
                doFuncNeedGps(md);
            } else if ("roomClose"==ft) {
                //房间需要关闭
                doFuncRoomClose(md);
            }
        }
    } else {
        for (var i=list.length-1;i>=0;i--) {
            var md = list[i];
            //容错 比较房间号
            if (needChkRoomKeyTag && md.roomKey!=pm.roomKey) {
                continue;
            }
            
            //数据类型
            var dt = md.dataType;
            if (keyHtml==dt) {
                //显示html数据
                doMsgHtml(md,false,'');
            }
        }
    }
    
    //需要滚动到最底部
    if (appendTag) {
        scrollToBottom();
    }
    
    //通知有新的消息 最小化时候
    if (pm.onMinimizeTag) {
        invokeUrl("chat://newMsgNumWhenMinimize/"+visibleMsgNum);
    }
}
function doMsgHtml(md,appendTag,waitId) {
    var hd = new ChatMsgHtmlData(md.data);
    //消息类别  1:我的消息  2:小秘书消息  3:时间  4:系统消息
    var dsTag = md.dataStyleTag;
    //样式
    var iconUrl = '';
    var c0 = '';
    var c1 = '';
    var c2 = '';
    var c3 = '';
    if (dsTag==1 || dsTag==2) {
        c0 = "cm_c";
        if (dsTag==1) {
            iconUrl = 'img/pic_me.png';
            c1 = "fr";
            c2 = "cm_me";
            c3 = 'cm_me_div';
        } else {
            iconUrl = 'img/pic_xms.png';
            c1 = "fl";
            c2 = "cm_xms";
            c3 = 'cm_xms_div';
        }
        var tstr = md.chatterIconUrl;
        if (tstr!='') {
            iconUrl = tstr;
        }
    } else if (dsTag==3) {
        c0 = "cm_time";
    } else {
        c0 = "cm_sys";
    }
    
    //html---------------------------------
    var html = new StringBuffer();
    html.append("<div class='"+c0+"'>");
    if (dsTag==1 || dsTag==2) {
        //1:我的消息  2:小秘书消息
        html.append("<div class='cm_pic "+c1+"'>");
        html.append("  <img src='"+iconUrl+"'>");
        html.append("</div>");
        html.append("<div class='"+c2+"'>");
        html.append("  <div class='cm_html "+c3+"'>");
        html.append("    "+hd.html);
        html.append("  </div>");
        if (dsTag==1 && waitId!='') {
            html.append("<div class='cm_me_wait' id='"+waitId+"'><img src='img/wait.gif'></div>");
        }
        html.append("</div>");
    } else {
        //3:时间 4:系统消息
        html.append("  "+hd.html);
    }
    html.append("</div>");
    if (appendTag) {
        chatPanel.append(html.toString());
    } else {
        chatPanel.prepend(html.toString());
    }
}

function doFuncNeedGps(md) {
    //invoke需要gps
    invokeUrl("chat://needGps");
}

function doFuncRoomClose(md) {
    //关闭房间
    closeRoom();
}



/*------------------------------------------------------------------------------
 |  对象
 |
 ------------------------------------------------------------------------------*/
//ChatPack
function ChatPack(obj) {
    //200：成功  其他：错误代码
	this.code = 0;
	//提示
	this.msg = '';
	//对象
	this.obj = null;
	
	//新的版本
	this.chatVer = '';
	//新的版本下载地址
	this.chatZipUrl = '';
    
	//初始化参数
	this.iniObj(obj);
}
ChatPack.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
    //200：成功  其他：错误代码
	if (obj.code!=undefined) {
		this.code = obj.code;
	}
    //提示
    if (obj.msg!=undefined) {
		this.msg = obj.msg;
	}
	//对象
    if (obj.obj!=undefined) {
		this.obj = obj.obj;
	}
	
	//新的版本
    if (obj.chatVer!=undefined) {
		this.chatVer = obj.chatVer;
	}
	//新的版本下载地址
    if (obj.chatZipUrl!=undefined) {
		this.chatZipUrl = obj.chatZipUrl;
	}
}



//ChatEnterRoomData
function ChatEnterRoomData(obj) {
	//房间钥匙
	this.roomKey = '';
	//用户id
	this.chatterId = '';
	//历史消息
	this.hisMsg = new ChatHisMsgPack();
    
    //初始化参数
	this.iniObj(obj);
}
ChatEnterRoomData.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
	//房间钥匙
    if (obj.roomKey!=undefined) {
		this.roomKey = obj.roomKey;
	}
	//用户id
    if (obj.chatterId!=undefined) {
		this.chatterId = obj.chatterId;
	}
    //历史消息
    if (obj.hisMsg!=undefined) {
		this.hisMsg = new ChatHisMsgPack(obj.hisMsg);
	}
}



//ChatMsgPack
function ChatMsgPack(obj) {
	//消息列表
	this.list = new Array();
	
    //初始化参数
	this.iniObj(obj);
}
ChatMsgPack.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
	//消息列表
    if (obj.list!=undefined) {
        for (var i=0;i<obj.list.length;i++) {
            var o = obj.list[i];
            this.list[i] = new ChatMsgData(o);
        }
	}
}



//ChatMsgData
function ChatMsgData(obj) {
    //房间钥匙
	this.roomKey = '';
	//用户id
	this.chatterId = '';
	
	//聊天人头像 如果是我的消息，头像为空 使用本地头像
	this.chatterIconUrl = '';
    
	//功能类别 默认为空  roomClose:房间关闭
	this.funcType = '';
	//功能数据 默认为空
	this.funcData = null;
	
	//数据类别
	this.dataType = '';
    //数据样式类别  1:我的消息  2：小秘书消息     3:时间    4：系统消息
	this.dataStyleTag = 4;
	//数据 json格式
	this.data = null;
	
    //初始化参数
	this.iniObj(obj);
}
ChatMsgData.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
    //房间钥匙
    if (obj.roomKey!=undefined) {
		this.roomKey = obj.roomKey;
	}
	//用户id
    if (obj.chatterId!=undefined) {
		this.chatterId = obj.chatterId;
	}
    
    //聊天人头像 如果是我的消息，头像为空 使用本地头像
    if (obj.chatterIconUrl!=undefined) {
		this.chatterIconUrl = obj.chatterIconUrl;
	}
    
	//功能类别 默认为空  roomClose:房间关闭
    if (obj.funcType!=undefined) {
		this.funcType = obj.funcType;
	}
	//功能数据 默认为空
    if (obj.funcData!=undefined) {
		this.funcData = obj.funcData;
	}
	
	//数据类别
    if (obj.dataType!=undefined) {
		this.dataType = obj.dataType;
	}
    //数据样式类别  1:我的消息  2：小秘书消息     3:时间    4：系统消息
    if (obj.dataStyleTag!=undefined) {
		this.dataStyleTag = obj.dataStyleTag;
	}
	//数据 json格式
    if (obj.data!=undefined) {
		this.data = obj.data;
	}
}



//ChatMsgHtmlData
function ChatMsgHtmlData(obj) {
    //文本
	this.html = '';
	
    //初始化参数
	this.iniObj(obj);
}
ChatMsgHtmlData.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
    //文本
    if (obj.html!=undefined) {
		this.html = obj.html;
	}
}



//ChatHisMsgPack
function ChatHisMsgPack(obj) {
	//消息列表
	this.list = new Array();
    //是否有上一笔数据
	this.havePrevTag = false;
	//上一笔数据id
	this.prevId = '';
	
    //初始化参数
	this.iniObj(obj);
}
ChatHisMsgPack.prototype.iniObj = function (obj) {
	if (obj==undefined) obj={};
	//消息列表
    if (obj.list!=undefined) {
        for (var i=0;i<obj.list.length;i++) {
            var o = obj.list[i];
            this.list[i] = new ChatMsgData(o);
        }
	}
    //是否有上一笔数据
    if (obj.havePrevTag!=undefined) {
		this.havePrevTag = obj.havePrevTag;
	}
	//上一笔数据id
    if (obj.prevId!=undefined) {
		this.prevId = obj.prevId;
	}
}



/*------------------------------------------------------------------------------
 |  其他
 |
 -----------------------------------------------------------------------------*/
//关闭房间
function closeRoomNotInvokeRoomClose(){
    closeRoomWithTag(false);
}
function closeRoom(){
    closeRoomWithTag(true);
}
function closeRoomWithTag(needInvokeRoomCloseTag){
    //房间是否已经关闭
    pm.roomClosedTag = true;
    //是否在聊天
    pm.onChattingTag = false;
    //断开连接
    socket.disconnect();
    //告诉客户端房间已经关闭
    if (needInvokeRoomCloseTag) {
        invokeUrl("chat://roomClosed");
    }
}

//检查是否下线了
function chkIsOffline(){
    if (pm.onChattingTag==false || pm.roomClosedTag) {
        return true;
    } else {
        return false;
    }
}

//显示错误提示
function showErrorHint(hint){
    var panel = $("#errorHintPanel");
    panel.empty();
    panel.append(hint);
    panel.show();
}

function showLoadMsg(msg) {
    var panel = $("#"+LOADING_PANEL_ID);
    panel.empty();
    panel.append(msg);
    panel.show();
}

function hideLoadMsg() {
    var panel = $("#"+LOADING_PANEL_ID);
    panel.hide();
}


//滚到最下面
function scrollToBottom() {
    $('html, body').animate({scrollTop: $(document).height()}, 500);
}

//滚到最下面 无动画
function moveToBottom() {
    $('html, body').scrollTop($(document).height());
}


//invoke url
function invokeUrl(url) {
    window.location.href = url;
}

//字符串处理
function StringBuffer(str) {
    this.tmp = new Array();
}
StringBuffer.prototype.append= function(value) {
    this.tmp.push(value);
    return this;
}
StringBuffer.prototype.clear = function() {
    tmp.length=1;
}
StringBuffer.prototype.toString = function() {
    return this.tmp.join('');
}


function randomString(len) {
　　len = len || 32;
　　var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
　　var maxPos = $chars.length;
　　var pwd = '';
　　for (i = 0; i < len; i++) {
    　　　　pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
　　return pwd;
}

function getCleanText(txt) {
    txt = replaceStr(txt,"<","&lt;");
    txt = replaceStr(txt,">","&gt;");
    txt = replaceStr(txt," ","&nbsp;");
    return txt;
}

function replaceStr(str,re,ne){
    while ( str.indexOf(re)!=-1 ) {
        str = str.replace(re,ne);
    }
    return str;
}
